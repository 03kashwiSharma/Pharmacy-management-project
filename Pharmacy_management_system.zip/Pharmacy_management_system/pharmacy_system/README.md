# Pharmacy Management System

A complete Pharmacy Management System built with Python, CustomTkinter (for a modern GUI with dark mode), and SQLite.

## Features
- **Inventory Management:** Add, update, delete, and search medicines. Track stock levels, prices, and expiry dates.
- **Sales/Billing (POS):** Add medicines to a cart, apply taxes and discounts, calculate totals, and generate PDF invoices.
- **Customer Management:** Store and manage customer details.
- **Supplier Management:** Store and manage supplier details.
- **Reports:** View daily sales, low stock alerts, and expired medicines. Export reports to CSV.
- **User Authentication:** Login system (default user: admin).
- **Modern UI:** Built with CustomTkinter for a sleek dark mode interface.

## Prerequisites
- Python 3.8+

## Setup Instructions

1. **Clone or Extract the Project:**
   Ensure you are in the `pharmacy_system` directory.

2. **Create a Virtual Environment (Optional but recommended):**
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows use `venv\Scripts\activate`
   ```

3. **Install Dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

4. **Initialize Database and Sample Data:**
   Run the sample data script to set up the database schema and populate it with sample suppliers, medicines, and customers.
   ```bash
   python -m database.sample_data
   ```

5. **Run the Application:**
   ```bash
   python main.py
   ```

## Default Login Credentials
- **Username:** admin
- **Password:** admin123

## Notes
- Generated PDF invoices will be saved in the `invoices/` directory automatically created at runtime.
- CSV exports from the Reports tab will prompt you for a save location.
- You can scan barcodes directly into the search field in the Sales/Billing module.

## Architecture
- **database/**: Contains the SQLite setup script (`db_setup.py`) and all CRUD operations (`db_operations.py`).
- **gui/**: Contains all the CustomTkinter views (Login, Dashboard, Inventory, Sales, etc.).
- **utils/**: Contains helper scripts like `pdf_generator.py` for invoices.
