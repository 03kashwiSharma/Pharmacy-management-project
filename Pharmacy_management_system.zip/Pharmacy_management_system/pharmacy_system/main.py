import customtkinter as ctk
import os
from database.db_setup import setup_database
from gui.login_view import LoginWindow
from gui.main_dashboard import MainDashboard

class PharmacyApp(ctk.CTk):
    def __init__(self):
        super().__init__()
        
        self.title("Pharmacy Management System")
        self.geometry("1024x768")
        self.minsize(800, 600)
        
        # Initialize Theme
        ctk.set_appearance_mode("Dark")
        ctk.set_default_color_theme("blue")
        
        # Ensure database is set up
        if not os.path.exists("pharmacy.db"):
            setup_database()
            
        # Bypass login by directly setting a default user
        self.current_user = {"id": 1, "username": "admin", "role": "admin"}
        self.show_dashboard()

    def show_dashboard(self):
        # Clear existing frames
        for widget in self.winfo_children():
            widget.destroy()
            
        self.dashboard = MainDashboard(self, self.current_user, self.on_logout)

    def on_logout(self):
        # If user logs out, we'll just close the application since login is bypassed
        self.destroy()

if __name__ == "__main__":
    app = PharmacyApp()
    app.mainloop()
from database.db_setup import setup_database
from database.db_operations import add_supplier, add_customer, add_medicine, process_sale
from datetime import datetime, timedelta

def populate_sample_data():
    print("Setting up database schema...")
    setup_database()

    print("Adding suppliers...")
    # Add Suppliers
    add_supplier("PharmaCorp Inc.", "John Doe", "1234567890", "contact@pharmacorp.com", "123 Pharma St")
    add_supplier("MediSupply LLC", "Jane Smith", "0987654321", "sales@medisupply.com", "456 Health Ave")

    print("Adding medicines...")
    # Add Medicines
    # Supplier 1
    next_year = (datetime.now() + timedelta(days=365)).strftime("%Y-%m-%d")
    last_month = (datetime.now() - timedelta(days=30)).strftime("%Y-%m-%d") # Expired
    
    add_medicine("Paracetamol 500mg", "Painkiller", 1, 100, 2.50, next_year, "BATCH001")
    add_medicine("Amoxicillin 250mg", "Antibiotic", 1, 5, 5.00, next_year, "BATCH002") # Low stock
    add_medicine("Ibuprofen 400mg", "Painkiller", 2, 50, 3.00, next_year, "BATCH003")
    add_medicine("Vitamin C", "Supplement", 2, 200, 1.50, last_month, "BATCH004") # Expired
    
    # More medicines
    add_medicine("Lisinopril 10mg", "Blood Pressure", 1, 150, 8.00, next_year, "BATCH005")
    add_medicine("Metformin 500mg", "Diabetes", 2, 300, 4.50, next_year, "BATCH006")
    add_medicine("Omeprazole 20mg", "Antacid", 1, 80, 6.00, next_year, "BATCH007")
    add_medicine("Cetirizine 10mg", "Antihistamine", 2, 120, 2.00, next_year, "BATCH008")
    add_medicine("Atorvastatin 20mg", "Cholesterol", 1, 90, 12.00, next_year, "BATCH009")
    add_medicine("Aspirin 81mg", "Blood Thinner", 2, 250, 1.00, next_year, "BATCH010")
    add_medicine("Levothyroxine 50mcg", "Thyroid", 1, 60, 9.50, next_year, "BATCH011")
    add_medicine("Azithromycin 250mg", "Antibiotic", 2, 40, 15.00, next_year, "BATCH012")
    add_medicine("Sertraline 50mg", "Antidepressant", 1, 75, 11.00, next_year, "BATCH013")
    add_medicine("Amlodipine 5mg", "Blood Pressure", 2, 110, 5.50, next_year, "BATCH014")
    add_medicine("Albuterol Inhaler", "Asthma", 1, 20, 25.00, next_year, "BATCH015")
    add_medicine("Pantoprazole 40mg", "Antacid", 2, 60, 7.50, next_year, "BATCH016")
    add_medicine("Gabapentin 300mg", "Nerve Pain", 1, 85, 14.00, next_year, "BATCH017")
    add_medicine("Fluticasone Nasal Spray", "Allergy", 2, 45, 18.00, next_year, "BATCH018")
    add_medicine("Losartan 50mg", "Blood Pressure", 1, 130, 9.00, next_year, "BATCH019")
    add_medicine("Citalopram 20mg", "Antidepressant", 2, 90, 10.50, next_year, "BATCH020")

    print("Adding customers...")
    # Add Customers
    c1 = add_customer("Alice Brown", "1112223333", "789 Elm St")
    c2 = add_customer("Bob White", "4445556666", "321 Oak St")

    print("Sample data populated successfully.")

if __name__ == "__main__":
    populate_sample_data()
    from fpdf import FPDF
import os

def generate_invoice_pdf(invoice_number, date, customer_name, cart_items, total, tax, discount, net_amount):
    pdf = FPDF()
    pdf.add_page()
    
    # Title
    pdf.set_font("Arial", 'B', 16)
    pdf.cell(200, 10, txt="Pharmacy Management System", ln=True, align='C')
    pdf.set_font("Arial", 'B', 12)
    pdf.cell(200, 10, txt="INVOICE", ln=True, align='C')
    
    pdf.ln(10)
    
    # Details
    pdf.set_font("Arial", size=10)
    pdf.cell(100, 8, txt=f"Invoice No: {invoice_number}")
    pdf.cell(90, 8, txt=f"Date: {date}", ln=True, align='R')
    pdf.cell(100, 8, txt=f"Customer: {customer_name}", ln=True)
    
    pdf.ln(5)
    
    # Table Header
    pdf.set_font("Arial", 'B', 10)
    pdf.cell(80, 8, txt="Medicine", border=1)
    pdf.cell(30, 8, txt="Qty", border=1, align='C')
    pdf.cell(40, 8, txt="Price", border=1, align='C')
    pdf.cell(40, 8, txt="Subtotal", border=1, align='C', ln=True)
    
    # Table Content
    pdf.set_font("Arial", size=10)
    for item in cart_items:
        pdf.cell(80, 8, txt=str(item['name']), border=1)
        pdf.cell(30, 8, txt=str(item['quantity']), border=1, align='C')
        pdf.cell(40, 8, txt=f"Rs. {item['price']:.2f}", border=1, align='C')
        pdf.cell(40, 8, txt=f"Rs. {item['subtotal']:.2f}", border=1, align='C', ln=True)
        
    pdf.ln(5)
    
    # Totals
    pdf.set_font("Arial", 'B', 10)
    pdf.cell(150, 8, txt="Total Amount:", align='R')
    pdf.cell(40, 8, txt=f"Rs. {total:.2f}", align='C', ln=True)
    
    pdf.cell(150, 8, txt="Tax:", align='R')
    pdf.cell(40, 8, txt=f"Rs. {tax:.2f}", align='C', ln=True)
    
    pdf.cell(150, 8, txt="Discount:", align='R')
    pdf.cell(40, 8, txt=f"Rs. {discount:.2f}", align='C', ln=True)
    
    pdf.set_font("Arial", 'B', 12)
    pdf.cell(150, 10, txt="Net Amount:", align='R')
    pdf.cell(40, 10, txt=f"Rs. {net_amount:.2f}", align='C', ln=True)
    
    # Ensure invoices directory exists
    if not os.path.exists("invoices"):
        os.makedirs("invoices")
        
    filepath = f"invoices/{invoice_number}.pdf"
    pdf.output(filepath)
    return filepath

