from fpdf import FPDF
import os

def generate_invoice_pdf(invoice_number, date, customer_name, cart_items, total, tax, discount, net_amount):
    pdf = FPDF()
    pdf.add_page()
    
    # Title
    pdf.set_font("Arial", 'B', 16)
    pdf.cell(200, 10, txt="Pharmacy Management System", ln=True, align='C')
    pdf.set_font("Arial", 'B', 12)
    pdf.cell(200, 10, txt="INVOICE", ln=True, align='C')
    
    pdf.ln(10)
    
    # Details
    pdf.set_font("Arial", size=10)
    pdf.cell(100, 8, txt=f"Invoice No: {invoice_number}")
    pdf.cell(90, 8, txt=f"Date: {date}", ln=True, align='R')
    pdf.cell(100, 8, txt=f"Customer: {customer_name}", ln=True)
    
    pdf.ln(5)
    
    # Table Header
    pdf.set_font("Arial", 'B', 10)
    pdf.cell(80, 8, txt="Medicine", border=1)
    pdf.cell(30, 8, txt="Qty", border=1, align='C')
    pdf.cell(40, 8, txt="Price", border=1, align='C')
    pdf.cell(40, 8, txt="Subtotal", border=1, align='C', ln=True)
    
    # Table Content
    pdf.set_font("Arial", size=10)
    for item in cart_items:
        pdf.cell(80, 8, txt=str(item['name']), border=1)
        pdf.cell(30, 8, txt=str(item['quantity']), border=1, align='C')
        pdf.cell(40, 8, txt=f"Rs. {item['price']:.2f}", border=1, align='C')
        pdf.cell(40, 8, txt=f"Rs. {item['subtotal']:.2f}", border=1, align='C', ln=True)
        
    pdf.ln(5)
    
    # Totals
    pdf.set_font("Arial", 'B', 10)
    pdf.cell(150, 8, txt="Total Amount:", align='R')
    pdf.cell(40, 8, txt=f"Rs. {total:.2f}", align='C', ln=True)
    
    pdf.cell(150, 8, txt="Tax:", align='R')
    pdf.cell(40, 8, txt=f"Rs. {tax:.2f}", align='C', ln=True)
    
    pdf.cell(150, 8, txt="Discount:", align='R')
    pdf.cell(40, 8, txt=f"Rs. {discount:.2f}", align='C', ln=True)
    
    pdf.set_font("Arial", 'B', 12)
    pdf.cell(150, 10, txt="Net Amount:", align='R')
    pdf.cell(40, 10, txt=f"Rs. {net_amount:.2f}", align='C', ln=True)
    
    # Ensure invoices directory exists
    if not os.path.exists("invoices"):
        os.makedirs("invoices")
        
    filepath = f"invoices/{invoice_number}.pdf"
    pdf.output(filepath)
    return filepath
