import customtkinter as ctk
from gui.inventory_view import InventoryView
from gui.sales_view import SalesView
from gui.customer_view import CustomerView
from gui.supplier_view import SupplierView
from gui.reports_view import ReportsView

class MainDashboard(ctk.CTkFrame):
    def __init__(self, master, current_user, on_logout):
        super().__init__(master)
        self.master = master
        self.current_user = current_user
        self.on_logout = on_logout

        self.pack(fill="both", expand=True)
        self.grid_rowconfigure(0, weight=1)
        self.grid_columnconfigure(1, weight=1)

        # Sidebar
        self.sidebar_frame = ctk.CTkFrame(self, width=200, corner_radius=0)
        self.sidebar_frame.grid(row=0, column=0, sticky="nsew")
        self.sidebar_frame.grid_rowconfigure(8, weight=1)

        self.logo_label = ctk.CTkLabel(self.sidebar_frame, text="PharmaSys", font=ctk.CTkFont(size=20, weight="bold"))
        self.logo_label.grid(row=0, column=0, padx=20, pady=(20, 10))
        
        self.user_label = ctk.CTkLabel(self.sidebar_frame, text=f"User: {self.current_user['username']}\nRole: {self.current_user['role']}")
        self.user_label.grid(row=1, column=0, padx=20, pady=(0, 20))

        # Navigation Buttons
        self.btn_sales = ctk.CTkButton(self.sidebar_frame, text="Billing / POS", command=lambda: self.show_frame("sales"))
        self.btn_sales.grid(row=2, column=0, padx=20, pady=10)

        self.btn_inventory = ctk.CTkButton(self.sidebar_frame, text="Inventory", command=lambda: self.show_frame("inventory"))
        self.btn_inventory.grid(row=3, column=0, padx=20, pady=10)

        self.btn_customers = ctk.CTkButton(self.sidebar_frame, text="Customers", command=lambda: self.show_frame("customers"))
        self.btn_customers.grid(row=4, column=0, padx=20, pady=10)

        self.btn_suppliers = ctk.CTkButton(self.sidebar_frame, text="Suppliers", command=lambda: self.show_frame("suppliers"))
        self.btn_suppliers.grid(row=5, column=0, padx=20, pady=10)

        self.btn_reports = ctk.CTkButton(self.sidebar_frame, text="Reports", command=lambda: self.show_frame("reports"))
        self.btn_reports.grid(row=6, column=0, padx=20, pady=10)

        # Appearance Mode
        self.appearance_mode_optionemenu = ctk.CTkOptionMenu(self.sidebar_frame, values=["Dark", "Light", "System"],
                                                               command=self.change_appearance_mode_event)
        self.appearance_mode_optionemenu.grid(row=9, column=0, padx=20, pady=(10, 10))
        self.appearance_mode_optionemenu.set("Dark")

        # Logout Button
        self.btn_logout = ctk.CTkButton(self.sidebar_frame, text="Logout", command=self.on_logout, fg_color="red", hover_color="darkred")
        self.btn_logout.grid(row=10, column=0, padx=20, pady=(10, 20))

        # Main Content Area
        self.main_content_frame = ctk.CTkFrame(self)
        self.main_content_frame.grid(row=0, column=1, sticky="nsew", padx=20, pady=20)
        self.main_content_frame.grid_rowconfigure(0, weight=1)
        self.main_content_frame.grid_columnconfigure(0, weight=1)

        # Initialize Views
        self.views = {}
        self.views["sales"] = SalesView(self.main_content_frame, self.current_user)
        self.views["inventory"] = InventoryView(self.main_content_frame)
        self.views["customers"] = CustomerView(self.main_content_frame)
        self.views["suppliers"] = SupplierView(self.main_content_frame)
        self.views["reports"] = ReportsView(self.main_content_frame)

        # Show Default View
        self.show_frame("sales")

    def show_frame(self, frame_name):
        for view in self.views.values():
            view.grid_forget()
        self.views[frame_name].grid(row=0, column=0, sticky="nsew")
        if hasattr(self.views[frame_name], 'refresh_data'):
            self.views[frame_name].refresh_data()

    def change_appearance_mode_event(self, new_appearance_mode: str):
        ctk.set_appearance_mode(new_appearance_mode)
