import customtkinter as ctk
from tkinter import ttk, filedialog, messagebox
import csv
from database.db_operations import get_low_stock_medicines, get_expired_medicines, get_daily_sales

class ReportsView(ctk.CTkFrame):
    def __init__(self, master):
        super().__init__(master)
        
        self.grid_rowconfigure(1, weight=1)
        self.grid_columnconfigure(0, weight=1)
        
        # Top bar
        self.top_frame = ctk.CTkFrame(self)
        self.top_frame.grid(row=0, column=0, sticky="ew", padx=10, pady=10)
        
        self.report_type = ctk.CTkComboBox(self.top_frame, values=["Daily Sales", "Low Stock", "Expired Medicines"], command=self.load_report)
        self.report_type.pack(side="left", padx=10)
        
        self.btn_export = ctk.CTkButton(self.top_frame, text="Export to CSV", command=self.export_csv)
        self.btn_export.pack(side="right", padx=10)

        # Treeview
        self.tree_frame = ctk.CTkFrame(self)
        self.tree_frame.grid(row=1, column=0, sticky="nsew", padx=10, pady=10)
        self.tree_frame.grid_rowconfigure(0, weight=1)
        self.tree_frame.grid_columnconfigure(0, weight=1)
        
        self.tree = ttk.Treeview(self.tree_frame, show="headings")
        self.tree.grid(row=0, column=0, sticky="nsew")
        
        self.current_data = []
        self.current_columns = []
        
        self.load_report("Daily Sales")

    def refresh_data(self):
        self.load_report(self.report_type.get())

    def load_report(self, report_name):
        for item in self.tree.get_children():
            self.tree.delete(item)
            
        if report_name == "Daily Sales":
            self.current_columns = ("Invoice Number", "Date", "Net Amount")
            self.current_data = get_daily_sales()
        elif report_name == "Low Stock":
            self.current_columns = ("ID", "Name", "Quantity", "Price")
            self.current_data = get_low_stock_medicines(10)
        elif report_name == "Expired Medicines":
            self.current_columns = ("ID", "Name", "Expiry Date", "Quantity")
            self.current_data = get_expired_medicines()
            
        self.tree["columns"] = self.current_columns
        for col in self.current_columns:
            self.tree.heading(col, text=col)
            self.tree.column(col, width=120)
            
        for row in self.current_data:
            self.tree.insert("", "end", values=row)

    def export_csv(self):
        if not self.current_data:
            messagebox.showinfo("Info", "No data to export")
            return
            
        filepath = filedialog.asksaveasfilename(
            defaultextension=".csv",
            filetypes=[("CSV files", "*.csv"), ("All files", "*.*")],
            title="Save Report as CSV"
        )
        if not filepath:
            return
            
        try:
            with open(filepath, mode='w', newline='', encoding='utf-8') as file:
                writer = csv.writer(file)
                writer.writerow(self.current_columns)
                writer.writerows(self.current_data)
            messagebox.showinfo("Success", f"Report exported successfully to {filepath}")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to export: {str(e)}")
