import customtkinter as ctk
from tkinter import messagebox
from database.db_operations import verify_login

class LoginWindow(ctk.CTkFrame):
    def __init__(self, master, on_login_success):
        super().__init__(master)
        self.master = master
        self.on_login_success = on_login_success
        
        self.pack(fill="both", expand=True)
        self.grid_rowconfigure(0, weight=1)
        self.grid_rowconfigure(4, weight=1)
        self.grid_columnconfigure(0, weight=1)
        self.grid_columnconfigure(2, weight=1)

        # Login Frame
        self.login_frame = ctk.CTkFrame(self, corner_radius=15, width=400, height=350)
        self.login_frame.grid(row=1, column=1, rowspan=3, sticky="nsew")
        self.login_frame.grid_propagate(False)
        
        self.login_frame.grid_rowconfigure(0, weight=1)
        self.login_frame.grid_rowconfigure(6, weight=1)
        self.login_frame.grid_columnconfigure(0, weight=1)
        self.login_frame.grid_columnconfigure(2, weight=1)

        # Title
        self.title_label = ctk.CTkLabel(self.login_frame, text="Pharmacy Management", font=ctk.CTkFont(size=24, weight="bold"))
        self.title_label.grid(row=1, column=1, pady=(20, 20))

        # Username
        self.username_entry = ctk.CTkEntry(self.login_frame, placeholder_text="Username", width=250)
        self.username_entry.grid(row=2, column=1, pady=10)

        # Password
        self.password_entry = ctk.CTkEntry(self.login_frame, placeholder_text="Password", show="*", width=250)
        self.password_entry.grid(row=3, column=1, pady=10)

        # Login Button
        self.login_button = ctk.CTkButton(self.login_frame, text="Login", command=self.attempt_login, width=250)
        self.login_button.grid(row=4, column=1, pady=20)

    def attempt_login(self):
        username = self.username_entry.get()
        password = self.password_entry.get()
        
        if not username or not password:
            messagebox.showerror("Error", "Please enter both username and password")
            return
            
        user = verify_login(username, password)
        if user:
            self.on_login_success(user)
        else:
            messagebox.showerror("Login Failed", "Invalid username or password")
