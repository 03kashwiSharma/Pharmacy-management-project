import customtkinter as ctk
from tkinter import ttk, messagebox
from database.db_operations import get_all_customers, add_customer

class CustomerView(ctk.CTkFrame):
    def __init__(self, master):
        super().__init__(master)
        
        self.grid_rowconfigure(1, weight=1)
        self.grid_columnconfigure(0, weight=1)
        
        # Top bar
        self.top_frame = ctk.CTkFrame(self)
        self.top_frame.grid(row=0, column=0, sticky="ew", padx=10, pady=10)
        
        self.btn_refresh = ctk.CTkButton(self.top_frame, text="Refresh", command=self.refresh_data)
        self.btn_refresh.pack(side="left", padx=5)
        
        self.btn_add = ctk.CTkButton(self.top_frame, text="Add Customer", command=self.show_add_dialog)
        self.btn_add.pack(side="right", padx=10)
        
        # Treeview
        self.tree_frame = ctk.CTkFrame(self)
        self.tree_frame.grid(row=1, column=0, sticky="nsew", padx=10, pady=10)
        self.tree_frame.grid_rowconfigure(0, weight=1)
        self.tree_frame.grid_columnconfigure(0, weight=1)
        
        columns = ("ID", "Name", "Phone", "Address")
        self.tree = ttk.Treeview(self.tree_frame, columns=columns, show="headings")
        for col in columns:
            self.tree.heading(col, text=col)
            self.tree.column(col, width=150)
            
        self.tree.grid(row=0, column=0, sticky="nsew")
        self.refresh_data()

    def refresh_data(self):
        for item in self.tree.get_children():
            self.tree.delete(item)
        data = get_all_customers()
        for row in data:
            self.tree.insert("", "end", values=row)

    def show_add_dialog(self):
        dialog = ctk.CTkToplevel(self)
        dialog.title("Add Customer")
        dialog.geometry("300x300")
        dialog.grab_set()
        
        ctk.CTkLabel(dialog, text="Name:").pack(pady=(10,0))
        entry_name = ctk.CTkEntry(dialog)
        entry_name.pack(pady=(0,10))
        
        ctk.CTkLabel(dialog, text="Phone:").pack(pady=(10,0))
        entry_phone = ctk.CTkEntry(dialog)
        entry_phone.pack(pady=(0,10))
        
        ctk.CTkLabel(dialog, text="Address:").pack(pady=(10,0))
        entry_address = ctk.CTkEntry(dialog)
        entry_address.pack(pady=(0,20))

        def save():
            name = entry_name.get()
            phone = entry_phone.get()
            address = entry_address.get()
            if not name:
                messagebox.showerror("Error", "Name is required")
                return
            add_customer(name, phone, address)
            self.refresh_data()
            dialog.destroy()
            
        btn_save = ctk.CTkButton(dialog, text="Save", command=save)
        btn_save.pack()
