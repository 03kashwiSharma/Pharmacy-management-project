import customtkinter as ctk
from tkinter import ttk, messagebox
from datetime import datetime
import uuid
from database.db_operations import search_medicines, get_all_customers, process_sale
from utils.pdf_generator import generate_invoice_pdf

class SalesView(ctk.CTkFrame):
    def __init__(self, master, current_user):
        super().__init__(master)
        self.current_user = current_user
        self.cart = []
        self.total = 0.0
        self.tax_rate = 0.05
        
        self.grid_rowconfigure(0, weight=1)
        self.grid_columnconfigure(0, weight=2)
        self.grid_columnconfigure(1, weight=1)
        
        # Left Panel (Products)
        self.left_panel = ctk.CTkFrame(self)
        self.left_panel.grid(row=0, column=0, sticky="nsew", padx=10, pady=10)
        self.left_panel.grid_rowconfigure(2, weight=1)
        self.left_panel.grid_columnconfigure(0, weight=1)
        
        # Product Search
        self.search_frame = ctk.CTkFrame(self.left_panel, fg_color="transparent")
        self.search_frame.grid(row=0, column=0, sticky="ew", pady=10)
        
        self.search_entry = ctk.CTkEntry(self.search_frame, placeholder_text="Search Medicine or scan barcode...", width=300)
        self.search_entry.pack(side="left", padx=10)
        self.btn_search = ctk.CTkButton(self.search_frame, text="Search", command=self.search_product)
        self.btn_search.pack(side="left", padx=5)
        
        # Products List
        self.products_tree_frame = ctk.CTkFrame(self.left_panel)
        self.products_tree_frame.grid(row=2, column=0, sticky="nsew", padx=10, pady=10)
        self.products_tree_frame.grid_rowconfigure(0, weight=1)
        self.products_tree_frame.grid_columnconfigure(0, weight=1)
        
        columns = ("ID", "Name", "Stock", "Price", "Batch")
        self.products_tree = ttk.Treeview(self.products_tree_frame, columns=columns, show="headings")
        for col in columns:
            self.products_tree.heading(col, text=col)
            self.products_tree.column(col, width=80)
        self.products_tree.grid(row=0, column=0, sticky="nsew")
        
        # Add to Cart Form
        self.add_cart_frame = ctk.CTkFrame(self.left_panel, fg_color="transparent")
        self.add_cart_frame.grid(row=3, column=0, sticky="ew", pady=10)
        ctk.CTkLabel(self.add_cart_frame, text="Qty:").pack(side="left", padx=5)
        self.qty_entry = ctk.CTkEntry(self.add_cart_frame, width=50)
        self.qty_entry.pack(side="left", padx=5)
        self.qty_entry.insert(0, "1")
        self.btn_add_cart = ctk.CTkButton(self.add_cart_frame, text="Add to Cart ->", command=self.add_to_cart)
        self.btn_add_cart.pack(side="right", padx=10)
        
        # Right Panel (Cart & Checkout)
        self.right_panel = ctk.CTkFrame(self)
        self.right_panel.grid(row=0, column=1, sticky="nsew", padx=10, pady=10)
        self.right_panel.grid_rowconfigure(1, weight=1)
        self.right_panel.grid_columnconfigure(0, weight=1)
        
        # Customer Selection
        self.customer_frame = ctk.CTkFrame(self.right_panel, fg_color="transparent")
        self.customer_frame.grid(row=0, column=0, sticky="ew", pady=10, padx=10)
        ctk.CTkLabel(self.customer_frame, text="Customer:").pack(side="left")
        self.customer_combo = ctk.CTkComboBox(self.customer_frame, values=["Guest"])
        self.customer_combo.pack(side="left", padx=10, fill="x", expand=True)
        
        # Cart Tree
        self.cart_tree_frame = ctk.CTkFrame(self.right_panel)
        self.cart_tree_frame.grid(row=1, column=0, sticky="nsew", padx=10, pady=10)
        self.cart_tree_frame.grid_rowconfigure(0, weight=1)
        self.cart_tree_frame.grid_columnconfigure(0, weight=1)
        
        cart_cols = ("Name", "Qty", "Price", "Subtotal")
        self.cart_tree = ttk.Treeview(self.cart_tree_frame, columns=cart_cols, show="headings")
        for col in cart_cols:
            self.cart_tree.heading(col, text=col)
            self.cart_tree.column(col, width=60)
        self.cart_tree.grid(row=0, column=0, sticky="nsew")
        
        self.btn_remove_cart = ctk.CTkButton(self.right_panel, text="Remove Item", command=self.remove_from_cart)
        self.btn_remove_cart.grid(row=2, column=0, pady=5, padx=10, sticky="e")
        
        # Totals Frame
        self.totals_frame = ctk.CTkFrame(self.right_panel)
        self.totals_frame.grid(row=3, column=0, sticky="ew", padx=10, pady=10)
        
        self.lbl_subtotal = ctk.CTkLabel(self.totals_frame, text="Subtotal: ₹0.00")
        self.lbl_subtotal.pack(anchor="e", padx=10, pady=2)
        
        self.lbl_tax = ctk.CTkLabel(self.totals_frame, text="Tax (5%): ₹0.00")
        self.lbl_tax.pack(anchor="e", padx=10, pady=2)
        
        self.discount_frame = ctk.CTkFrame(self.totals_frame, fg_color="transparent")
        self.discount_frame.pack(anchor="e", padx=10, pady=2)
        ctk.CTkLabel(self.discount_frame, text="Discount: ₹").pack(side="left")
        self.discount_entry = ctk.CTkEntry(self.discount_frame, width=60)
        self.discount_entry.pack(side="left")
        self.discount_entry.insert(0, "0.0")
        self.discount_entry.bind("<KeyRelease>", self.update_totals_event)
        
        self.lbl_net = ctk.CTkLabel(self.totals_frame, text="Net Amount: ₹0.00", font=ctk.CTkFont(weight="bold", size=16))
        self.lbl_net.pack(anchor="e", padx=10, pady=5)
        
        self.btn_checkout = ctk.CTkButton(self.right_panel, text="Checkout & Print Bill", command=self.checkout, height=40, font=ctk.CTkFont(weight="bold"))
        self.btn_checkout.grid(row=4, column=0, pady=(10, 20), padx=10, sticky="ew")

        self.refresh_customers()
        self.search_product() # Load all initially

    def refresh_customers(self):
        customers = get_all_customers()
        vals = ["Guest"] + [f"{c[0]} - {c[1]}" for c in customers]
        self.customer_combo.configure(values=vals)

    def search_product(self):
        query = self.search_entry.get()
        data = search_medicines(query)
        for item in self.products_tree.get_children():
            self.products_tree.delete(item)
        for row in data:
            # ID, Name, Category, Supplier, Qty, Price, Expiry, Batch
            self.products_tree.insert("", "end", values=(row[0], row[1], row[4], row[5], row[7]))

    def add_to_cart(self):
        selected = self.products_tree.selection()
        if not selected:
            return
        
        item_values = self.products_tree.item(selected[0])['values']
        med_id = item_values[0]
        name = item_values[1]
        stock = float(item_values[2])
        price = float(item_values[3])
        
        try:
            qty = int(self.qty_entry.get())
        except ValueError:
            messagebox.showerror("Error", "Invalid quantity")
            return
            
        if qty <= 0:
            return
            
        if qty > stock:
            messagebox.showerror("Error", f"Only {stock} items available in stock.")
            return
            
        subtotal = price * qty
        
        # Check if already in cart
        for cart_item in self.cart:
            if cart_item['medicine_id'] == med_id:
                if cart_item['quantity'] + qty > stock:
                    messagebox.showerror("Error", "Exceeds stock limit.")
                    return
                cart_item['quantity'] += qty
                cart_item['subtotal'] = cart_item['quantity'] * price
                self.refresh_cart_tree()
                self.update_totals()
                return

        self.cart.append({
            'medicine_id': med_id,
            'name': name,
            'quantity': qty,
            'price': price,
            'subtotal': subtotal
        })
        self.refresh_cart_tree()
        self.update_totals()

    def remove_from_cart(self):
        selected = self.cart_tree.selection()
        if not selected:
            return
        idx = self.cart_tree.index(selected[0])
        self.cart.pop(idx)
        self.refresh_cart_tree()
        self.update_totals()

    def refresh_cart_tree(self):
        for item in self.cart_tree.get_children():
            self.cart_tree.delete(item)
        for item in self.cart:
            self.cart_tree.insert("", "end", values=(item['name'], item['quantity'], f"₹{item['price']:.2f}", f"₹{item['subtotal']:.2f}"))

    def update_totals_event(self, event):
        self.update_totals()

    def update_totals(self):
        self.total = sum(item['subtotal'] for item in self.cart)
        tax = self.total * self.tax_rate
        try:
            discount = float(self.discount_entry.get())
        except ValueError:
            discount = 0.0
            
        net = self.total + tax - discount
        
        self.lbl_subtotal.configure(text=f"Subtotal: ₹{self.total:.2f}")
        self.lbl_tax.configure(text=f"Tax (5%): ₹{tax:.2f}")
        self.lbl_net.configure(text=f"Net Amount: ₹{net:.2f}")
        
    def checkout(self):
        if not self.cart:
            messagebox.showwarning("Warning", "Cart is empty")
            return
            
        self.update_totals()
        tax = self.total * self.tax_rate
        try:
            discount = float(self.discount_entry.get())
        except ValueError:
            discount = 0.0
        net = self.total + tax - discount
        
        customer_val = self.customer_combo.get()
        customer_id = None
        customer_name = "Guest"
        if customer_val != "Guest":
            parts = customer_val.split(" - ")
            customer_id = int(parts[0])
            customer_name = parts[1]
            
        invoice_number = f"INV-{uuid.uuid4().hex[:8].upper()}"
        
        success = process_sale(invoice_number, customer_id, self.current_user['id'], self.total, tax, discount, net, self.cart)
        
        if success:
            date_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            filepath = generate_invoice_pdf(invoice_number, date_str, customer_name, self.cart, self.total, tax, discount, net)
            messagebox.showinfo("Success", f"Sale successful!\nInvoice saved to {filepath}")
            self.cart = []
            self.refresh_cart_tree()
            self.update_totals()
            self.search_product() # refresh stock
        else:
            messagebox.showerror("Error", "Failed to process sale.")
