import customtkinter as ctk
from tkinter import ttk, messagebox
from database.db_operations import get_all_medicines, search_medicines, delete_medicine, get_all_suppliers, add_medicine, update_medicine

class InventoryView(ctk.CTkFrame):
    def __init__(self, master):
        super().__init__(master)
        
        self.grid_rowconfigure(1, weight=1)
        self.grid_columnconfigure(0, weight=1)
        
        # Top bar: Search and Actions
        self.top_frame = ctk.CTkFrame(self)
        self.top_frame.grid(row=0, column=0, sticky="ew", padx=10, pady=10)
        
        self.search_entry = ctk.CTkEntry(self.top_frame, placeholder_text="Search by name, category, batch...", width=300)
        self.search_entry.pack(side="left", padx=10)
        
        self.btn_search = ctk.CTkButton(self.top_frame, text="Search", command=self.perform_search)
        self.btn_search.pack(side="left", padx=5)
        
        self.btn_refresh = ctk.CTkButton(self.top_frame, text="Refresh", command=self.refresh_data)
        self.btn_refresh.pack(side="left", padx=5)
        
        self.btn_add = ctk.CTkButton(self.top_frame, text="Add Medicine", command=self.show_add_dialog)
        self.btn_add.pack(side="right", padx=10)
        
        self.btn_edit = ctk.CTkButton(self.top_frame, text="Edit Selected", command=self.show_edit_dialog)
        self.btn_edit.pack(side="right", padx=5)
        
        self.btn_delete = ctk.CTkButton(self.top_frame, text="Delete Selected", command=self.delete_selected, fg_color="red", hover_color="darkred")
        self.btn_delete.pack(side="right", padx=5)

        # Treeview for Data
        self.tree_frame = ctk.CTkFrame(self)
        self.tree_frame.grid(row=1, column=0, sticky="nsew", padx=10, pady=10)
        self.tree_frame.grid_rowconfigure(0, weight=1)
        self.tree_frame.grid_columnconfigure(0, weight=1)
        
        columns = ("ID", "Name", "Category", "Supplier", "Qty", "Price", "Expiry", "Batch")
        self.tree = ttk.Treeview(self.tree_frame, columns=columns, show="headings")
        
        for col in columns:
            self.tree.heading(col, text=col)
            self.tree.column(col, width=100)
            
        # Styling Treeview
        style = ttk.Style()
        style.theme_use("default")
        style.configure("Treeview", background="#2a2d2e", foreground="white", rowheight=25, fieldbackground="#343638")
        style.map('Treeview', background=[('selected', '#22559b')])
        
        self.tree.grid(row=0, column=0, sticky="nsew")
        
        scrollbar = ttk.Scrollbar(self.tree_frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscroll=scrollbar.set)
        scrollbar.grid(row=0, column=1, sticky="ns")
        
        self.refresh_data()

    def refresh_data(self):
        for item in self.tree.get_children():
            self.tree.delete(item)
        data = get_all_medicines()
        for row in data:
            self.tree.insert("", "end", values=row)

    def perform_search(self):
        query = self.search_entry.get()
        if not query:
            self.refresh_data()
            return
        for item in self.tree.get_children():
            self.tree.delete(item)
        data = search_medicines(query)
        for row in data:
            self.tree.insert("", "end", values=row)

    def delete_selected(self):
        selected = self.tree.selection()
        if not selected:
            messagebox.showwarning("Warning", "Please select a medicine to delete")
            return
        item_id = self.tree.item(selected[0])['values'][0]
        if messagebox.askyesno("Confirm", "Are you sure you want to delete this medicine?"):
            delete_medicine(item_id)
            self.refresh_data()

    def show_add_dialog(self):
        self._show_form_dialog("Add Medicine")
        
    def show_edit_dialog(self):
        selected = self.tree.selection()
        if not selected:
            messagebox.showwarning("Warning", "Please select a medicine to edit")
            return
        values = self.tree.item(selected[0])['values']
        self._show_form_dialog("Edit Medicine", values)

    def _show_form_dialog(self, title, values=None):
        dialog = ctk.CTkToplevel(self)
        dialog.title(title)
        dialog.geometry("400x500")
        dialog.grab_set()
        
        suppliers = get_all_suppliers()
        supplier_options = [f"{s[0]} - {s[1]}" for s in suppliers]
        
        # Fields
        ctk.CTkLabel(dialog, text="Name:").pack(pady=(10,0))
        entry_name = ctk.CTkEntry(dialog)
        entry_name.pack(pady=(0,10))
        
        ctk.CTkLabel(dialog, text="Category:").pack(pady=(10,0))
        entry_category = ctk.CTkEntry(dialog)
        entry_category.pack(pady=(0,10))
        
        ctk.CTkLabel(dialog, text="Supplier:").pack(pady=(10,0))
        entry_supplier = ctk.CTkComboBox(dialog, values=supplier_options)
        entry_supplier.pack(pady=(0,10))
        
        ctk.CTkLabel(dialog, text="Quantity:").pack(pady=(10,0))
        entry_qty = ctk.CTkEntry(dialog)
        entry_qty.pack(pady=(0,10))
        
        ctk.CTkLabel(dialog, text="Price per unit:").pack(pady=(10,0))
        entry_price = ctk.CTkEntry(dialog)
        entry_price.pack(pady=(0,10))
        
        ctk.CTkLabel(dialog, text="Expiry Date (YYYY-MM-DD):").pack(pady=(10,0))
        entry_expiry = ctk.CTkEntry(dialog)
        entry_expiry.pack(pady=(0,10))
        
        ctk.CTkLabel(dialog, text="Batch Number:").pack(pady=(10,0))
        entry_batch = ctk.CTkEntry(dialog)
        entry_batch.pack(pady=(0,20))
        
        if values:
            entry_name.insert(0, values[1])
            entry_category.insert(0, values[2])
            # Set supplier is tricky, we'd need to match name, skip for now or set first
            entry_qty.insert(0, values[4])
            entry_price.insert(0, values[5])
            entry_expiry.insert(0, values[6])
            entry_batch.insert(0, values[7])

        def save():
            name = entry_name.get()
            category = entry_category.get()
            supplier_val = entry_supplier.get()
            supplier_id = int(supplier_val.split(" - ")[0]) if supplier_val else None
            try:
                qty = int(entry_qty.get())
                price = float(entry_price.get())
            except ValueError:
                messagebox.showerror("Error", "Quantity must be int, price must be float")
                return
            expiry = entry_expiry.get()
            batch = entry_batch.get()
            
            if values:
                update_medicine(values[0], name, category, supplier_id, qty, price, expiry, batch)
            else:
                add_medicine(name, category, supplier_id, qty, price, expiry, batch)
            
            self.refresh_data()
            dialog.destroy()
            
        btn_save = ctk.CTkButton(dialog, text="Save", command=save)
        btn_save.pack()
