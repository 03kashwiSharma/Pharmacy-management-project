import sqlite3
import hashlib
from datetime import datetime
from database.db_setup import get_connection

# ================= USER OPERATIONS =================

def verify_login(username, password):
    conn = get_connection()
    cursor = conn.cursor()
    pwd_hash = hashlib.sha256(password.encode()).hexdigest()
    cursor.execute("SELECT id, username, role FROM users WHERE username=? AND password_hash=?", (username, pwd_hash))
    user = cursor.fetchone()
    conn.close()
    if user:
        return {"id": user[0], "username": user[1], "role": user[2]}
    return None

def get_all_users():
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT id, username, role FROM users")
    users = cursor.fetchall()
    conn.close()
    return users

# ================= MEDICINE OPERATIONS =================

def add_medicine(name, category, supplier_id, quantity, price_per_unit, expiry_date, batch_number):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute('''
        INSERT INTO medicines (name, category, supplier_id, quantity, price_per_unit, expiry_date, batch_number)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ''', (name, category, supplier_id, quantity, price_per_unit, expiry_date, batch_number))
    conn.commit()
    conn.close()

def update_medicine(med_id, name, category, supplier_id, quantity, price_per_unit, expiry_date, batch_number):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute('''
        UPDATE medicines
        SET name=?, category=?, supplier_id=?, quantity=?, price_per_unit=?, expiry_date=?, batch_number=?
        WHERE id=?
    ''', (name, category, supplier_id, quantity, price_per_unit, expiry_date, batch_number, med_id))
    conn.commit()
    conn.close()

def delete_medicine(med_id):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM medicines WHERE id=?", (med_id,))
    conn.commit()
    conn.close()

def get_all_medicines():
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute('''
        SELECT m.id, m.name, m.category, s.name as supplier_name, m.quantity, m.price_per_unit, m.expiry_date, m.batch_number
        FROM medicines m
        LEFT JOIN suppliers s ON m.supplier_id = s.id
    ''')
    data = cursor.fetchall()
    conn.close()
    return data

def search_medicines(query):
    conn = get_connection()
    cursor = conn.cursor()
    search_term = f"%{query}%"
    cursor.execute('''
        SELECT m.id, m.name, m.category, s.name as supplier_name, m.quantity, m.price_per_unit, m.expiry_date, m.batch_number
        FROM medicines m
        LEFT JOIN suppliers s ON m.supplier_id = s.id
        WHERE m.name LIKE ? OR m.category LIKE ? OR m.batch_number LIKE ?
    ''', (search_term, search_term, search_term))
    data = cursor.fetchall()
    conn.close()
    return data

def get_low_stock_medicines(threshold=10):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute('''
        SELECT id, name, quantity, price_per_unit 
        FROM medicines WHERE quantity <= ?
    ''', (threshold,))
    data = cursor.fetchall()
    conn.close()
    return data

def get_expired_medicines():
    conn = get_connection()
    cursor = conn.cursor()
    today = datetime.now().strftime("%Y-%m-%d")
    cursor.execute('''
        SELECT id, name, expiry_date, quantity 
        FROM medicines WHERE expiry_date < ?
    ''', (today,))
    data = cursor.fetchall()
    conn.close()
    return data

# ================= SUPPLIER OPERATIONS =================

def add_supplier(name, contact_person, phone, email, address):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("INSERT INTO suppliers (name, contact_person, phone, email, address) VALUES (?, ?, ?, ?, ?)",
                   (name, contact_person, phone, email, address))
    conn.commit()
    conn.close()

def get_all_suppliers():
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM suppliers")
    data = cursor.fetchall()
    conn.close()
    return data

def delete_supplier(sup_id):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM suppliers WHERE id=?", (sup_id,))
    conn.commit()
    conn.close()

# ================= CUSTOMER OPERATIONS =================

def add_customer(name, phone, address):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("INSERT INTO customers (name, phone, address) VALUES (?, ?, ?)", (name, phone, address))
    customer_id = cursor.lastrowid
    conn.commit()
    conn.close()
    return customer_id

def get_all_customers():
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM customers")
    data = cursor.fetchall()
    conn.close()
    return data

def search_customer_by_phone(phone):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM customers WHERE phone=?", (phone,))
    data = cursor.fetchone()
    conn.close()
    return data

def get_customer_purchase_history(customer_id):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute('''
        SELECT invoice_number, date, net_amount 
        FROM sales WHERE customer_id=? ORDER BY date DESC
    ''', (customer_id,))
    data = cursor.fetchall()
    conn.close()
    return data

# ================= SALES & BILLING OPERATIONS =================

def process_sale(invoice_number, customer_id, user_id, total_amount, tax, discount, net_amount, cart_items):
    """
    cart_items: list of dicts with keys: medicine_id, quantity, price, subtotal
    """
    conn = get_connection()
    cursor = conn.cursor()
    try:
        date_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        cursor.execute('''
            INSERT INTO sales (invoice_number, customer_id, user_id, date, total_amount, tax, discount, net_amount)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ''', (invoice_number, customer_id, user_id, date_str, total_amount, tax, discount, net_amount))
        
        sale_id = cursor.lastrowid
        
        for item in cart_items:
            cursor.execute('''
                INSERT INTO sale_items (sale_id, medicine_id, quantity, price, subtotal)
                VALUES (?, ?, ?, ?, ?)
            ''', (sale_id, item['medicine_id'], item['quantity'], item['price'], item['subtotal']))
            
            # Reduce inventory
            cursor.execute('''
                UPDATE medicines SET quantity = quantity - ? WHERE id = ?
            ''', (item['quantity'], item['medicine_id']))
        
        conn.commit()
        return True
    except Exception as e:
        print("Error processing sale:", e)
        conn.rollback()
        return False
    finally:
        conn.close()

def get_daily_sales():
    conn = get_connection()
    cursor = conn.cursor()
    today = datetime.now().strftime("%Y-%m-%d")
    cursor.execute('''
        SELECT invoice_number, date, net_amount 
        FROM sales WHERE date LIKE ?
    ''', (f"{today}%",))
    data = cursor.fetchall()
    conn.close()
    return data
