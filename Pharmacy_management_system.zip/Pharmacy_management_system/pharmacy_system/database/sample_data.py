from database.db_setup import setup_database
from database.db_operations import add_supplier, add_customer, add_medicine, process_sale
from datetime import datetime, timedelta

def populate_sample_data():
    print("Setting up database schema...")
    setup_database()

    print("Adding suppliers...")
    # Add Suppliers
    add_supplier("PharmaCorp Inc.", "John Doe", "1234567890", "contact@pharmacorp.com", "123 Pharma St")
    add_supplier("MediSupply LLC", "Jane Smith", "0987654321", "sales@medisupply.com", "456 Health Ave")

    print("Adding medicines...")
    # Add Medicines
    # Supplier 1
    next_year = (datetime.now() + timedelta(days=365)).strftime("%Y-%m-%d")
    last_month = (datetime.now() - timedelta(days=30)).strftime("%Y-%m-%d") # Expired
    
    add_medicine("Paracetamol 500mg", "Painkiller", 1, 100, 2.50, next_year, "BATCH001")
    add_medicine("Amoxicillin 250mg", "Antibiotic", 1, 5, 5.00, next_year, "BATCH002") # Low stock
    add_medicine("Ibuprofen 400mg", "Painkiller", 2, 50, 3.00, next_year, "BATCH003")
    add_medicine("Vitamin C", "Supplement", 2, 200, 1.50, last_month, "BATCH004") # Expired
    
    # More medicines
    add_medicine("Lisinopril 10mg", "Blood Pressure", 1, 150, 8.00, next_year, "BATCH005")
    add_medicine("Metformin 500mg", "Diabetes", 2, 300, 4.50, next_year, "BATCH006")
    add_medicine("Omeprazole 20mg", "Antacid", 1, 80, 6.00, next_year, "BATCH007")
    add_medicine("Cetirizine 10mg", "Antihistamine", 2, 120, 2.00, next_year, "BATCH008")
    add_medicine("Atorvastatin 20mg", "Cholesterol", 1, 90, 12.00, next_year, "BATCH009")
    add_medicine("Aspirin 81mg", "Blood Thinner", 2, 250, 1.00, next_year, "BATCH010")
    add_medicine("Levothyroxine 50mcg", "Thyroid", 1, 60, 9.50, next_year, "BATCH011")
    add_medicine("Azithromycin 250mg", "Antibiotic", 2, 40, 15.00, next_year, "BATCH012")
    add_medicine("Sertraline 50mg", "Antidepressant", 1, 75, 11.00, next_year, "BATCH013")
    add_medicine("Amlodipine 5mg", "Blood Pressure", 2, 110, 5.50, next_year, "BATCH014")
    add_medicine("Albuterol Inhaler", "Asthma", 1, 20, 25.00, next_year, "BATCH015")
    add_medicine("Pantoprazole 40mg", "Antacid", 2, 60, 7.50, next_year, "BATCH016")
    add_medicine("Gabapentin 300mg", "Nerve Pain", 1, 85, 14.00, next_year, "BATCH017")
    add_medicine("Fluticasone Nasal Spray", "Allergy", 2, 45, 18.00, next_year, "BATCH018")
    add_medicine("Losartan 50mg", "Blood Pressure", 1, 130, 9.00, next_year, "BATCH019")
    add_medicine("Citalopram 20mg", "Antidepressant", 2, 90, 10.50, next_year, "BATCH020")

    print("Adding customers...")
    # Add Customers
    c1 = add_customer("Alice Brown", "1112223333", "789 Elm St")
    c2 = add_customer("Bob White", "4445556666", "321 Oak St")

    print("Sample data populated successfully.")

if __name__ == "__main__":
    populate_sample_data()
